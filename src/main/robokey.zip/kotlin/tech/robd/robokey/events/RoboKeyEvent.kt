package tech.robd.robokey.events

import org.springframework.context.ApplicationEvent

class RoboKeyEvent(
    source: Any,
    val parentEvent: ParentEventContext,
    val eventType: EventType,
    val eventData: Any,
) : ApplicationEvent(source),
    Trackable {
    override val eventId: String get() = parentEvent.eventId // Inherit the event ID from parent context

    override fun getEventDetails(): String = "TrackableEvent with ID: $eventId and data: $eventData"
}
