package tech.robd.robokey.events

import tech.robd.robokey.Logable
import tech.robd.robokey.setupLogs

interface Trackable : Logable {
    val eventId: String

    fun getEventDetails(): String

    /**
     * Logs details of the Trackable event.
     *
     * This function logs the details of a Trackable event, making use of the `setupLogs` logger.
     */
    fun logEventDetails() {
        val logger: org.slf4j.Logger = setupLogs
        logger.info("Tracking event: ID = $eventId, Details = ${getEventDetails()}")
    }
}
