package tech.robd.robokey.events

enum class EventSourceActor {
    WEB, // From the REST Controller
    COMMAND_LINE, // from the commandline interface
    FILE_WATCHER, // From the file watcher
    GUI, // from the GUI
    MICROCONTROLLER, // An event generated on the microcontroller NOT part of the flow of another command
    ERROR_MANAGER, // some error that cannot be assigned to a parent
}
