package tech.robd.robokey.events

import org.springframework.context.ApplicationEventPublisher
import java.time.Instant
import java.util.UUID

class ParentEventContext(
    private val eventPublisher: ApplicationEventPublisher, // Injected publisher for publishing events
    val eventId: String = UUID.randomUUID().toString(),
    val timestamp: Instant = Instant.now(),
    val eventSourceActor: EventSourceActor? = null,
    // note commands might be in eventCommand or this might be UNDEFINED and the commands in secondaryCommands
    val eventCommand: EventCommand = EventCommand.UNDEFINED,
    // Additional commands for complex processing, e.g. batches or when the command hasn't been determined yet
    val secondaryCommands: MutableList<EventCommand> = mutableListOf(),
    val eventValue: String? = null,
    val eventValues: List<String>? = eventValue?.let { listOf(it) },
) {
    init {
        // Automatically publish a START_EVENT upon instantiation
        publishRoboKeyEvent(EventType.START_EVENT, "ParentEventContext initialized")
    }

    /**
     * Helper method to create and publish a RoboKeyEvent based on this ParentEventContext.
     * @param eventType The type of event to publish.
     * @param data Optional data to include with the event.
     */
    fun publishRoboKeyEvent(
        eventType: EventType,
        data: String? = null,
    ) {
        val roboKeyEvent =
            RoboKeyEvent(
                // source = this,
                source = this,
                eventType = eventType,
                eventData = data ?: "Event from ParentEventContext with ID: $eventId",
                parentEvent = this,
            )
        eventPublisher.publishEvent(roboKeyEvent)
    }
}
