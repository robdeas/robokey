package tech.robd.robokey.events

import org.springframework.context.event.EventListener
import org.springframework.stereotype.Component

@Component
class RoboKeyEventListener : RoboKeyEventListenerInterface {

    @EventListener
    override fun handleRoboKeyEvent(event: RoboKeyEvent) {
        println("Event occurred: ${'$'}{event.eventType} with data: ${'$'}{event.data}")
        // Production logic for handling events
    }
}
