package tech.robd.robokey.events

import org.aspectj.lang.annotation.Aspect
import org.aspectj.lang.annotation.Before
import org.springframework.stereotype.Component

@Aspect
@Component
class LoggingAspect {

    @Before("execution(* tech.robd.robokey.events.RoboKeyEventListenerInterface.handleRoboKeyEvent(..)) && args(event)")
    fun logEvent(event: RoboKeyEvent) {
        println("Logging event: Type = ${'$'}{event.eventType}, Data = ${'$'}{event.data}")
    }
}
