package tech.robd.robokey.events

import org.springframework.context.ApplicationEventPublisher
import org.springframework.stereotype.Component

@Component // Registers this class as a Spring bean for dependency injection
class ParentEventContextProvider(
    private val eventPublisher: ApplicationEventPublisher,
) {
    /**
     * Factory method to create a new instance of ParentEventContext.
     *
     * @param eventSourceActor Optional source of the event (e.g., WEB, SYSTEM).
     * @param eventCommand Optional command associated with the event (e.g., PROCESS_COMMAND).
     * @param eventValue Optional main value associated with this event.
     * @return A fully initialized ParentEventContext ready for use.
     */
    fun createParentEventContext(
        eventSourceActor: EventSourceActor? = null,
        eventCommand: EventCommand = EventCommand.UNDEFINED,
        eventValue: String? = null,
    ): ParentEventContext =
        ParentEventContext(
            eventPublisher = eventPublisher,
            eventSourceActor = eventSourceActor,
            eventCommand = eventCommand,
            eventValue = eventValue,
        )
}
