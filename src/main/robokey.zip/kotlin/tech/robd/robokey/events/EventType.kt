package tech.robd.robokey.events

// the sort of steps that could occur in the application when an event might occur
enum class EventType {
    COMMAND_SENT,
    COMMAND_RECEIVED,
    KEYBOARD_EVENT,
    CLI_COMMAND,
    START_EVENT,
//    RESET_KEYBOARD,
//    RESUME_TYPING,
//    PAUSE_TYPING,
}
