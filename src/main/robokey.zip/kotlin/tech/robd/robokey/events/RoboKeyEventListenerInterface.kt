package tech.robd.robokey.events

interface RoboKeyEventListenerInterface {
    fun handleRoboKeyEvent(event: RoboKeyEvent)
}
