package tech.robd.robokey.events

enum class EventCommand {
    IS_ALIVE,
    LOREM,
    LOREM_LINES,
    STOP_TYPING,
    TEXT,
    UNDEFINED, // It is likely that some commands will be determined later
    KEY_PRESS,
    RESUME_TYPING,
    RESET_KEYBOARD,
    PAUSE_TYPING,
}
